package com.codingsector.calleruichanger.fromkolerapp

import android.content.Context
import androidx.annotation.StringRes
import androidx.preference.PreferenceManager

/*
 * A Singleton for managing your SharedPreferences.
 *_
 * IMPORTANT: The class is not thread safe. It should work fine in most
 * circumstances since the write and read operations are fast. However
 * if you call edit for bulk updates and do not commit your changes
 * there is a possibility of data loss if a background thread has modified
 * preferences at the same time.
 */
class PreferencesManager private constructor(val _context: Context) {
    private val _pref by lazy { PreferenceManager.getDefaultSharedPreferences(_context) }

    fun putString(@StringRes key: Int, value: String?) {
        _pref.edit().putString(_context.getString(key), value).apply()
    }

    fun getString(@StringRes key: Int, defaultValue: String? = null) =
        _pref.getString(_context.getString(key), defaultValue)

    companion object : SingletonHolder<PreferencesManager, Context>(::PreferencesManager)
}