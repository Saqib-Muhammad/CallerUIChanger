package com.codingsector.calleruichanger

import android.content.Context
import android.telecom.Call

fun Call.getNumber() = details?.gatewayInfo?.originalAddress?.schemeSpecificPart
    ?: details?.handle?.schemeSpecificPart

fun Call.lookupContact(context: Context) =
    getNumber()?.let {
        (context.applicationContext as CallerUIChanger).componentRoot.phoneAccountsInteractor.lookupAccount(
            it
        )
    }