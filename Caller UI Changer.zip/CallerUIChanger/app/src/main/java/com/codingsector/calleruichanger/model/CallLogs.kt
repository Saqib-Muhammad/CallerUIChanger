package com.codingsector.calleruichanger.model

data class CallLogs(var name: String)