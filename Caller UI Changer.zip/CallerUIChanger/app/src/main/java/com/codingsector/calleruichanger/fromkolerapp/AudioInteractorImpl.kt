package com.codingsector.calleruichanger.fromkolerapp

import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Vibrator
import android.view.KeyEvent
import androidx.annotation.RequiresApi
import java.util.HashMap

class AudioInteractorImpl(
    private val vibrator: Vibrator,
    private val audioManager: AudioManager
) : BaseInteractorImpl<AudioInteractor.Listener>(), AudioInteractor {

    override val isPhoneSilent: Boolean
        get() = audioManager.ringerMode in arrayOf(
            AudioManager.RINGER_MODE_SILENT,
            AudioManager.RINGER_MODE_VIBRATE
        )

    override fun playTone(tone: Int) {
        playTone(tone, TONE_LENGTH_MS)
    }

    @RequiresApi(Build.VERSION_CODES.N)
    override fun playToneByKey(keyCode: Int) {
        playTone(sKeyToTone.getOrDefault(keyCode, -1))
    }

    override fun playTone(tone: Int, durationMs: Int) {
        if (tone != -1 && isPhoneSilent) {
            synchronized(sToneGeneratorLock) {
                ToneGenerator(DIAL_TONE_STREAM_TYPE, TONE_RELATIVE_VOLUME).startTone(
                    tone, durationMs
                ) // Start the new tone (will stop any playing tone)
            }
        }
    }

    companion object {
        const val TONE_LENGTH_MS = 150 // The length of DTMF tones in milliseconds
        const val DIAL_TONE_STREAM_TYPE = android.media.AudioManager.STREAM_DTMF
        const val TONE_RELATIVE_VOLUME =
            80 // The DTMF tone volume relative to other sounds in the stream

        private val sToneGeneratorLock = Any()
        private val sKeyToTone by lazy {
            HashMap<Int, Int>().apply {
                put(KeyEvent.KEYCODE_0, ToneGenerator.TONE_DTMF_0)
                put(KeyEvent.KEYCODE_1, ToneGenerator.TONE_DTMF_1)
                put(KeyEvent.KEYCODE_2, ToneGenerator.TONE_DTMF_2)
                put(KeyEvent.KEYCODE_3, ToneGenerator.TONE_DTMF_3)
                put(KeyEvent.KEYCODE_4, ToneGenerator.TONE_DTMF_4)
                put(KeyEvent.KEYCODE_5, ToneGenerator.TONE_DTMF_5)
                put(KeyEvent.KEYCODE_6, ToneGenerator.TONE_DTMF_6)
                put(KeyEvent.KEYCODE_7, ToneGenerator.TONE_DTMF_7)
                put(KeyEvent.KEYCODE_8, ToneGenerator.TONE_DTMF_8)
                put(KeyEvent.KEYCODE_9, ToneGenerator.TONE_DTMF_9)
                put(KeyEvent.KEYCODE_POUND, ToneGenerator.TONE_DTMF_P)
                put(KeyEvent.KEYCODE_STAR, ToneGenerator.TONE_DTMF_S)
            }
        }
    }
}
