package com.codingsector.calleruichanger.fromkolerapp

import android.content.Context
import android.os.Bundle
import android.view.KeyEvent
import android.view.KeyEvent.*
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.KeyEventDispatcher.dispatchKeyEvent
import androidx.fragment.app.Fragment
import com.codingsector.calleruichanger.CallerUIChanger

abstract class BaseFragment : Fragment(), BaseContract.View {
    protected val baseActivity by lazy { context as BaseActivity }
    protected val componentRoot by lazy { (baseActivity.applicationContext as CallerUIChanger).componentRoot }

    val argsSafely: Bundle
        get() = arguments ?: Bundle()

    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (context !is BaseActivity) {
            throw TypeCastException("Fragment not a child of base activity")
        }
        baseActivity.onAttachFragment(this)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
//        onSetup()
    }

    fun reattach() {
        childFragmentManager.beginTransaction().detach(this).attach(this).commitNow()
    }

    fun pressBack() {
        baseActivity.apply {
            dispatchKeyEvent(KeyEvent(ACTION_DOWN, KEYCODE_BACK))
            dispatchKeyEvent(KeyEvent(ACTION_UP, KEYCODE_BACK))
        }
    }
}