package com.codingsector.calleruichanger.fromkolerapp

import android.util.Log
import android.view.KeyEvent

interface CallActionsContract : BaseContract {
    interface View : BaseContract.View {
        fun openDialpad()
    }

    interface Presenter<V : View> : BaseContract.Presenter<V> {
        fun onHoldClick()
        fun onKeypadClick()
        fun onKeypadKey(keyCode: Int, event: KeyEvent)
    }
}