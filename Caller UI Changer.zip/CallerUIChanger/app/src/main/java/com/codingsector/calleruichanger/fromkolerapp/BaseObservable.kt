package com.codingsector.calleruichanger.fromkolerapp

import java.util.*
import kotlin.collections.HashSet

open class BaseObservable<Listener> {
    private val _listeners by lazy { HashSet<Listener>() }

    val listeners: Set<Listener>
        get() = Collections.unmodifiableSet(_listeners)
}