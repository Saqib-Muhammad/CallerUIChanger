package com.codingsector.calleruichanger.fromkolerapp

import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.telecom.TelecomManager
import android.widget.Toast

class PermissionInteractorImpl(
    private val context: Context,
    private val telecomManager: TelecomManager
) : BaseObservable<PermissionInteractor.Listener>(),
    PermissionInteractor {

    override val isDefaultDialer: Boolean
        get() = context.packageName == telecomManager.defaultDialerPackage

    override fun requestDefaultDialer() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = context.getSystemService(Context.ROLE_SERVICE) as RoleManager
            context.startActivity(roleManager.createRequestRoleIntent(RoleManager.ROLE_DIALER))
        } else {
            val intent = Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
            intent.putExtra(
                TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME,
                context.packageName
            )
            context.startActivity(intent)
        }
    }

    override fun runWithDefaultDialer(errorMessageRes: Int?, callback: () -> Unit) {
            if (!isDefaultDialer) {
                checkDefaultDialer(errorMessageRes)
            } else {
                callback.invoke()
            }
        }

    override fun checkDefaultDialer(errorMessageRes: Int?) {
        if (!isDefaultDialer) {
            requestDefaultDialer()
            errorMessageRes?.let {
                Toast.makeText(context, context.getString(errorMessageRes), Toast.LENGTH_SHORT)
                    .show()
            }
        }
    }
}