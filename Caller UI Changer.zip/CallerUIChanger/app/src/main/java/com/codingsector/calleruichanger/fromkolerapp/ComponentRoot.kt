package com.codingsector.calleruichanger.fromkolerapp

import android.app.KeyguardManager
import android.media.AudioManager
import android.os.Vibrator
import android.telecom.TelecomManager

interface ComponentRoot {
    val vibrator: Vibrator
    val audioManager: AudioManager
    val keyguardManager: KeyguardManager
    val telecomManager: TelecomManager
    val preferencesManager: PreferencesManager

    val audioInteractor: AudioInteractor
    val permissionInteractor: PermissionInteractor
    val preferencesInteractor: PreferencesInteractor
    val phoneAccountsInteractor: PhoneAccountsInteractor
}