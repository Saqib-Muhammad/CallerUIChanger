package com.codingsector.calleruichanger.fromkolerapp.dialpad




import android.content.Context
import android.os.Build
import android.os.Bundle
import android.telephony.PhoneNumberFormattingTextWatcher
import android.text.style.TtsSpan.ARG_NUMBER
import android.view.KeyEvent
import android.view.KeyEvent.ACTION_DOWN
import android.view.KeyEvent.KEYCODE_DEL
import android.view.LayoutInflater
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import androidx.databinding.adapters.TextViewBindingAdapter.setText
import com.codingsector.calleruichanger.databinding.DialpadBinding
import com.codingsector.calleruichanger.databinding.KeypadBtmBinding
import com.codingsector.calleruichanger.fragments.ContactsFragment
import com.codingsector.calleruichanger.fromkolerapp.BaseFragment
import com.codingsector.calleruichanger.fromkolerapp.CallManager
import com.codingsector.calleruichanger.fromkolerapp.DialpadKey

class DialpadFragment : BaseFragment(), DialpadContract.View {
    private var _onTextChangedListener: (text: String?) -> Unit? = { _ -> }
    private val _binding by lazy { KeypadBtmBinding.inflate(layoutInflater) }
    private var _onKeyDownListener: (keyCode: Int, event: KeyEvent) -> Unit? = { _, _ -> }
    private val _presenter by lazy { DialpadPresenter<DialpadContract.View>(this) }
//    private val _suggestionsFragment by lazy { ContactSFragment.newInstance(true, false) }

    override val isDialer by lazy { argsSafely.getBoolean(ARG_IS_DIALER) }

//    override val suggestionsCount: Int
//    get() = _suisAddContactButtonVisible

    override var number: String
        get() = _binding.dialpadEditText.text.toString()
        set(value) {
            _binding.dialpadEditText.setText(value)
        }

//    override var isSuggestionsVisible: Boolean
//        get() = _binding.dialpadSuggestionsScrollView.visibility == VISIBLE
//        set(value) {
//            if (value && !isSuggestionsVisibile) {
//                componentRoot.animationInteractor.animateIn(_binding.dialpadSuggestionsScrollView)
//            } else if (!value && isSuggestionsVisibile) {
//                _binding.dialpadSuggestionsScrollView.visibility = GONE
//            }
//        }

//    override var isAddContactButtonVisible: Boolean
//        get() = _binding.dialpadButtonAddContact.visibility == VISIBLE
//        set(value) {
//            if (value && !isAddContactButtonVisible) {
//                componentRoot.animationInteractor.animateIn(_binding.dialpadButtonAddCont)
//            } else if (!value && isAddContactButtonVisible) {
//                componentRoot.animationInteractor.showView(_binding.dialpadButtonAddContact, false)
//            }
//        }

//    override var isDeleteButtonVisible: Boolean
//        get() = _binding.dialpadButtonDelete.visibility == VISIBLE
//        set(value) {
//            if (value && !isDeleteButtonVisible) {
//                componetRoot.animationInteractor.animateIn(_binding.dialpadButtonDelete)
//            } else if (!value && isDeleteButtonVisible) {
//                componentRoot.animationInteractor.showView(_binding.dialpadButtonDelete, false)
//            }
//        }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ) = _binding.root

    override fun onSetup() {
//        _suggestionFragment.setOnContactsChangedListener(_presenter::onSuggestionChanged)

        _binding.apply {
            dialpadEditText.apply {
                isClickable = isDialer
                isLongClickable = isDialer
                isFocusableInTouchMode = isDialer

                if (isDialer) {
                    addTextChangedListener(PhoneNumberFormattingTextWatcher())
                }
                setText(argsSafely.getString(ARG_NUMBER))
                addOnTextChangedListener {
                    _presenter.onTextChanged(it)
                    _onTextChangedListener.invoke(it)
                }
            }

            View.OnClickListener { it ->
                (it as DialpadKey).keyCode.also {
                    _presenter.onKeyClick(it)
                    _onKeyDownListener.invoke(it, KeyEvent(ACTION_DOWN, it))
                }
            }.also {
                key0.setOnClickListener(it)
                key1.setOnClickListener(it)
                key2.setOnClickListener(it)
                key3.setOnClickListener(it)
                key4.setOnClickListener(it)
                key5.setOnClickListener(it)
                key6.setOnClickListener(it)
                key7.setOnClickListener(it)
                key8.setOnClickListener(it)
                key9.setOnClickListener(it)
                keyHex.setOnClickListener(it)
                keyStar.setOnClickListener(it)
            }
//
//            View.OnLongClickListener {
//                _presenter.onLongKeyClick((it as DialpadKey).keyCode)
//            }.also {
//                key0.setOnClickListener(it)
//                key1.setOnClickListener(it)
//                key2.setOnClickListener(it)
//                key3.setOnClickListener(it)
//                key4.setOnClickListener(it)
//                key5.setOnClickListener(it)
//                key6.setOnClickListener(it)
//                key7.setOnClickListener(it)
//                key8.setOnClickListener(it)
//                key9.setOnClickListener(it)
//                keyHex.setOnClickListener(it)
//                keyStar.setOnClickListener(it)
//            }

            _presenter.onTextChanged(dialpadEditText.text.toString())
        }
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
//        childFragmentManager
//            .beginTransaction()
//            .add(_binding.dialpadSuggestionsContainer.id, _suggestionsFragment)
//            .commitNow()
    }

    //region dialpad view

    override fun call() {
        if (number.isEmpty()) {
            baseActivity.showMessage("Please enter a number first")
        } else {
            CallManager.call(baseActivity, _binding.dialpadEditText.text.toString())
        }
    }

    override fun backspace() {
        _binding.dialpadEditText.onKeyDown(KEYCODE_DEL, KeyEvent(ACTION_DOWN, KEYCODE_DEL))
    }

    @RequiresApi(Build.VERSION_CODES.N)
    override fun playTone(keyCode: Int) {
        componentRoot.audioInteractor.playToneByKey(keyCode)
    }

    override fun invokeKey(keyCode: Int) {
        _binding.dialpadEditText.onKeyDown(keyCode, KeyEvent(ACTION_DOWN, keyCode))
    }

    //endregion

    fun setOnTextChangedListener(onTextChangeListener: (text: String?) -> Unit?) {
        _onTextChangedListener = onTextChangeListener
    }

    fun setOnKeyDownListener(onKeyDownListener: (keyCode: Int, event: KeyEvent) -> Unit?) {
        _onKeyDownListener = onKeyDownListener
    }

    override fun showMessage(message: String) {
        TODO("Not yet implemented")
    }

    override fun showMessage(stringResId: Int) {
        TODO("Not yet implemented")
    }

    override var isDeleteButtonVisible: Boolean
        get() = TODO("Not yet implemented")
        set(value) {}
    override var isAddContactButtonVisible: Boolean
        get() = TODO("Not yet implemented")
        set(value) {}

    override fun setSuggestionsFilter(filter: String) {
        TODO("Not yet implemented")
    }

    override fun vibrate() {
        TODO("Not yet implemented")
    }

    companion object {
        const val TAG = "dialpad_bottom_dialog_fragment"
        const val ARG_IS_DIALER = "dialer"
        const val ARG_NUMBER = "number"

        fun newInstance(isDialer: Boolean, number: String? = null) = DialpadFragment().apply {
            arguments = Bundle().apply {
                putBoolean(ARG_IS_DIALER, isDialer)
                putString(ARG_NUMBER, number)
            }
        }
    }
}