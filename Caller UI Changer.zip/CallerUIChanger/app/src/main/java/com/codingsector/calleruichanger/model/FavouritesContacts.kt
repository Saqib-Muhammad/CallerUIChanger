package com.codingsector.calleruichanger.model

data class FavouritesContacts(var title: String)
