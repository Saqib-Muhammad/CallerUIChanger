package com.codingsector.calleruichanger.fromkolerapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.codingsector.calleruichanger.CallerUIChanger

abstract class BaseActivity : AppCompatActivity(), BaseContract.View {
    protected val componentRoot by lazy { (applicationContext as CallerUIChanger).componentRoot }
//    protected val boundComponentRoot by lazy { BoundComponentRootImpl(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(componentRoot.preferencesInteractor.accentTheme.theme)
        super.onCreate(savedInstanceState)
    }

    override fun onStart() {
        super.onStart()
        onSetup()
    }

    override fun finish() {
        TODO("Not yet implemented")
    }

    override fun showMessage(stringResId: Int) {
        showMessage(getString(stringResId))
    }
}