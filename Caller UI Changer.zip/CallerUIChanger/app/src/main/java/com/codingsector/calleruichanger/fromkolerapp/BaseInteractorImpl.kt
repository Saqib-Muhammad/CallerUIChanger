package com.codingsector.calleruichanger.fromkolerapp


open class BaseInteractorImpl<Listener> : BaseObservable<Listener>(), BaseInteractor<Listener>
