package com.codingsector.calleruichanger.fromkolerapp

interface BaseInteractor<Listener> {
}