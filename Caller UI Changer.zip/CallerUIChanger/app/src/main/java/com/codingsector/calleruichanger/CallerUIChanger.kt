package com.codingsector.calleruichanger

import android.app.Application
import android.content.res.Resources
import android.os.Build
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.app.AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
import com.codingsector.calleruichanger.fromkolerapp.ComponentRootImpl

open class CallerUIChanger : Application() {

    val componentRoot by lazy {
        ComponentRootImpl(this)
    }

    override fun onCreate() {
        super.onCreate()
        CallerUIChanger.resources = resources
        AppCompatDelegate.setDefaultNightMode(MODE_NIGHT_FOLLOW_SYSTEM)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//            CallNotification(this).createNotificationChannel()
        }
    }

    companion object {
        var resources: Resources? = null
    }
}