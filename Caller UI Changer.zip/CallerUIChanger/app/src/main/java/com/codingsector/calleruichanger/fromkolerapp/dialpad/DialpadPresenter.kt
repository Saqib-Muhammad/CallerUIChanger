package com.codingsector.calleruichanger.fromkolerapp.dialpad

import android.view.KeyEvent
import com.codingsector.calleruichanger.fromkolerapp.BasePresenter

class DialpadPresenter<V : DialpadContract.View>(mvpView: V) :
BasePresenter<V>(mvpView),
DialpadContract.Presenter<V>{

    override fun onTextChanged(text: String?) {
        mvpView.apply {
            if (isDialer) {
                isDeleteButtonVisible = text?.isNotEmpty() == true
                isAddContactButtonVisible = text?.isNotEmpty() == true
                setSuggestionsFilter(text ?: "")
            }
        }
    }

    override fun onKeyClick(keyCode: Int) {
        mvpView.apply {
            vibrate()
            playTone(keyCode)
            invokeKey(keyCode)
        }
    }

//    override fun onLongKeyClick(keyCode: Int): Boolean {
//        return when (keyCode) {
//            KeyEvent.KEYCODE_0 -> {
//                onKeyClick(KeyEvent.KEYCODE_PLUS)
//                true
//            }
//            KeyEvent.KEYCODE_1 -> {
//                if (mvpView.isDialer) mvpView.callVoicemail()
//                mvpView.isDialer
//            }
//            else -> true
//        }
//    }
}