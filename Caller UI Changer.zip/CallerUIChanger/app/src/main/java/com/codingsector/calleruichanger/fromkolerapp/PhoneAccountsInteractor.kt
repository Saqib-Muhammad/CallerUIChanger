package com.codingsector.calleruichanger.fromkolerapp

import android.telecom.PhoneAccount

interface PhoneAccountsInteractor : BaseInteractor<PhoneAccountsInteractor.Listener> {
    interface Listener

    fun lookupAccount(number: String): PhoneLookupAccount?
    fun getContactAccounts(contactId: Long): Array<PhoneAccount>
}