package com.codingsector.calleruichanger.fromkolerapp

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.telecom.Call
import androidx.annotation.RequiresApi
import com.codingsector.calleruichanger.CallerUIChanger
import com.codingsector.calleruichanger.R

object CallManager {
    var sCall: Call? = null

    fun keypad(c: Char) {
        sCall?.playDtmfTone(c)
        sCall?.stopDtmfTone()
    }

    fun hold(isHold: Boolean) {
        if (isHold) {
            sCall?.hold()
        } else {
            sCall?.unhold()
        }
    }

    fun call(context: Context, number: String) {
        (context.applicationContext as CallerUIChanger).componentRoot.permissionInteractor.runWithDefaultDialer(
            R.string.error_not_default_dialer_call
        ) {
            val callIntent = Intent(Intent.ACTION_CALL)
            callIntent.data = Uri.parse("tel:${Uri.encode(number)}")
            context.startActivity(callIntent)
        }
    }


    abstract class CallListener(protected val context: Context) : Call.Callback() {
        @RequiresApi(Build.VERSION_CODES.N)
        override fun onStateChanged(call: Call?, state: Int) {
            onCallDetailsChanged(CallDetails.fromCall(call, context))
        }

        @RequiresApi(Build.VERSION_CODES.N)
        override fun onDetailsChanged(call: Call?, details: Call.Details?) {
            onCallDetailsChanged(CallDetails.fromCall(call, context))
        }

        abstract fun onCallDetailsChanged(callDetails: CallDetails)
    }
}