package com.codingsector.calleruichanger.fromkolerapp

import android.app.Application
import android.app.KeyguardManager
import android.content.Context
import android.media.AudioManager
import android.os.Vibrator
import android.telecom.TelecomManager
import com.codingsector.calleruichanger.fromkolerapp.ComponentRoot

class ComponentRootImpl(internal val application: Application) : ComponentRoot {
    override val vibrator by lazy {
        application.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
    }

    override val keyguardManager: KeyguardManager
        get() = application.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager

    override val preferencesManager by lazy {
        PreferencesManager.getInstance(application)
    }

    override val audioManager by lazy {
        application.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    }

    override val telecomManager by lazy {
        application.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
    }

    override val audioInteractor by lazy {
        AudioInteractorImpl(vibrator, audioManager)
    }

    override val preferencesInteractor by lazy {
        PreferencesInteractorImpl(preferencesManager)
    }

    override val permissionInteractor by lazy {
        PermissionInteractorImpl(application, telecomManager)
    }

    override val phoneAccountsInteractor by lazy {
        PhoneAccountsInteractorImpl(application)
    }
}
