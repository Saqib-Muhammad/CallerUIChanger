package com.codingsector.calleruichanger.fromkolerapp

import android.content.Context
import android.os.Build
import android.provider.ContactsContract
import android.telecom.Call
import androidx.annotation.RequiresApi
import com.codingsector.calleruichanger.getNumber
import com.codingsector.calleruichanger.lookupContact

data class CallDetails(
    val callState: CallState,
    val details: Call.Details,
    val phoneAccount: PhoneLookupAccount,
) {
    companion object {
        @RequiresApi(Build.VERSION_CODES.N)
        fun fromCall(call: Call?, context: Context) = CallDetails(
            callState = CallState.values().associateBy(CallState::state)
                .getOrDefault(call!!.state, CallState.UNKNOWN),
            details = call.details,
            phoneAccount = call.lookupContact(context)
                ?: PhoneLookupAccount(
                    name = null,
                    number = call.getNumber(),
                    type = ContactsContract.CommonDataKinds.Phone.TYPE_OTHER
                )
        )
    }

    enum class CallState(val state: Int) {
        ACTIVE(Call.STATE_ACTIVE),
        CONNECTION(Call.STATE_CONNECTING),
        DIALING(Call.STATE_DIALING),
        DISCONNECTED(Call.STATE_DISCONNECTED),
        DISCONNECTING(Call.STATE_DISCONNECTING),
        HOLDING(Call.STATE_HOLDING),
        NEW(Call.STATE_NEW),

        @RequiresApi(Build.VERSION_CODES.N_MR1)
        PULLING_CALL(Call.STATE_PULLING_CALL),
        RINGING(Call.STATE_RINGING),
        SELECT_PHONE_ACCOUNT(Call.STATE_SELECT_PHONE_ACCOUNT),
        UNKNOWN(-1)
    }
}
