package com.codingsector.calleruichanger.fromkolerapp.dialpad

import com.codingsector.calleruichanger.fromkolerapp.BaseContract

interface DialpadContract : BaseContract {
    interface View : BaseContract.View {
        var number: String
        val isDialer: Boolean
        var isDeleteButtonVisible: Boolean
        var isAddContactButtonVisible: Boolean
        fun setSuggestionsFilter(filter: String)

        fun call()
        fun vibrate()
        fun backspace()
        fun playTone(keyCode: Int)
        fun invokeKey(keyCode: Int)
    }

    interface Presenter<V : View> : BaseContract.Presenter<V> {
        fun onKeyClick(keyCode: Int)
        fun onTextChanged(text: String?)
    }
}