package com.codingsector.calleruichanger.fromkolerapp

import android.content.Context
import android.telecom.PhoneAccount

class PhoneAccountsInteractorImpl(
    private val context: Context
) : BaseInteractorImpl<PhoneAccountsInteractor.Listener>(), PhoneAccountsInteractor {
    override fun lookupAccount(number: String): PhoneLookupAccount? {
        TODO()
    }

    override fun getContactAccounts(contactId: Long): Array<PhoneAccount> {
        TODO()
    }
}