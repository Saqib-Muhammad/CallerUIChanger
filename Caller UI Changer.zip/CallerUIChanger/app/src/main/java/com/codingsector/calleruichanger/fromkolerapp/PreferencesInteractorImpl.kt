package com.codingsector.calleruichanger.fromkolerapp

import com.codingsector.calleruichanger.R


class PreferencesInteractorImpl(
    private val preferencesManager: PreferencesManager
) : BaseInteractorImpl<PreferencesInteractor.Listener>(),
    PreferencesInteractor {

    override var accentTheme: PreferencesInteractor.Companion.AccentTheme
        get() = PreferencesInteractor.Companion.AccentTheme.fromKey(preferencesManager.getString(R.string.pref_key_color))
        set(value) {
            preferencesManager.putString(R.string.pref_key_color, value.key)
        }
    }