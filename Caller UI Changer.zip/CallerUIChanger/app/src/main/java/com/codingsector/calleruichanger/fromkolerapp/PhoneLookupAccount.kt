package com.codingsector.calleruichanger.fromkolerapp

import android.provider.ContactsContract

data class PhoneLookupAccount(
    val name: String?,
    val number: String?,
    val contactId: Long? = null,
    val photoUri: String? = null,
    val starred: Boolean? = false,
    val type: Int = ContactsContract.CommonDataKinds.Phone.TYPE_OTHER
)
