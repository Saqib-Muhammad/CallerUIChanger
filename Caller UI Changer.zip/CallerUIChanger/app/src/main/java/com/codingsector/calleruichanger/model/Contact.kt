package com.codingsector.calleruichanger.model

data class Contact(var name: String, var mobile: String)
