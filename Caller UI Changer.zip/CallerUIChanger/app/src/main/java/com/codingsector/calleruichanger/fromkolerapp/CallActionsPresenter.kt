package com.codingsector.calleruichanger.fromkolerapp

import android.view.KeyEvent

class CallActionsPresenter<V : CallActionsContract.View>(mvpView: V) :
    BasePresenter<V>(mvpView),
    CallActionsContract.Presenter<V> {

    private var _isHolding = false

    override fun onHoldClick() {
        _isHolding = !_isHolding
        CallManager.hold(_isHolding)
    }

    override fun onKeypadClick() {
        mvpView.openDialpad()
    }

    override fun onKeypadKey(keyCode: Int, event: KeyEvent) {
        CallManager.keypad(event.number)
    }
}